```json
{
  "title": "沙砾砖",
  "icon": "supplementaries:gravel_bricks",
  "categories": [
    "minecraft:blocks",
    "minecraft:group/functional_blocks",
    "minecraft:group/building_blocks"
  ],
  "associated_items": [
    "supplementaries:gravel_bricks",
    "supplementaries:suspicious_gravel_bricks"
  ]
}
```

&spotlight(supplementaries:gravel_bricks)
**沙砾砖**是沙砾的砖块变种，在其上跳跃或摔落到其上会使得其损毁。

<block;supplementaries:gravel_bricks>

;;;;;

&title(合成)
<recipe;supplementaries:gravel_bricks>

;;;;;

&title(可疑变种)
其中埋有物品时会成为可疑的沙砾砖。
