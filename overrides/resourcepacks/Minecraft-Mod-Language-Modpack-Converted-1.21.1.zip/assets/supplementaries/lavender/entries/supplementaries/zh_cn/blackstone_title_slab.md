```json
{
  "title": "黑石瓦台阶",
  "icon": "supplementaries:blackstone_tile_slab",
  "categories": [
    "minecraft:blocks",
    "minecraft:tag/slabs",
    "minecraft:group/building_blocks"
  ],
  "associated_items": [
    "supplementaries:blackstone_tile_slab"
  ]
}
```

&spotlight(supplementaries:blackstone_tile_slab)
**黑石瓦台阶**是[黑石瓦](^supplementaries:blackstone_tiles)的[台阶](^minecraft:tag/slabs)变种。

;;;;;

&title(合成)
<recipe;supplementaries:blackstone_tile_slab>
<recipe;supplementaries:stonecutting/blackstone_tile_slab>
