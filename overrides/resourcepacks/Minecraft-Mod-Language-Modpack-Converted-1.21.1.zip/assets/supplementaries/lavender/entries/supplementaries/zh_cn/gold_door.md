```json
{
  "title": "金门",
  "icon": "supplementaries:gold_door",
  "categories": [
    "minecraft:blocks",
    "minecraft:tag/doors",
    "minecraft:group/building_blocks",
    "minecraft:group/redstone_blocks"
  ],
  "associated_items": [
    "supplementaries:gold_door"
  ]
}
```

&spotlight(supplementaries:gold_door)
**金门**是使用金制造的[门](^minecraft:tag/doors)，玩家无法与被红石充能的金门交互。


也即，被红石充能的金门无法打开也无法关闭，无论其当前是已打开还是已关闭。

;;;;;

&title(合成)
<recipe;supplementaries:gold_door>
