```json
{
  "title": "饲料堆",
  "icon": "supplementaries:fodder",
  "categories": [
    "minecraft:blocks",
    "minecraft:group/functional_blocks"
  ],
  "associated_items": [
    "supplementaries:fodder"
  ]
}
```

&spotlight(supplementaries:fodder)
**饲料堆**是分为多层的方块，能够自动喂食动物。

<block;supplementaries:fodder>

;;;;;

&title(合成)
<recipe;supplementaries:fodder>

手持锄点击可移除一层饲料。

;;;;;

&title(用途)
许多动物（由标签控制）在饥饿时会尝试食用一层饲料。


食用后，幼年生物会成长得更快，成年生物则会[坠入爱河](^minecraft:breeding)。使用原版冷却时间。

;;;;;

&title(红石)
可由发射器放置。
