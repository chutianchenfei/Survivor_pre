```json
{
  "title": "深板岩灯",
  "icon": "supplementaries:deepslate_lamp",
  "categories": [
    "minecraft:blocks",
    "minecraft:group/functional_blocks",
    "supplementaries:lamps"
  ],
  "associated_items": [
    "supplementaries:deepslate_lamp"
  ]
}
```

&spotlight(supplementaries:deepslate_lamp)
**深板岩灯**是[灯](^supplementaries:lamps)的[深板岩](^minecraft:deepslate)变种。

;;;;;

&title(合成)
<recipe;supplementaries:deepslate_lamp>