```json
{
  "title": "石瓦台阶",
  "icon": "supplementaries:stone_tile_slab",
  "categories": [
    "minecraft:blocks",
    "minecraft:tag/slabs",
    "minecraft:group/building_blocks"
  ],
  "associated_items": [
    "supplementaries:stone_tile_slab"
  ]
}
```

&spotlight(supplementaries:stone_tile_slab)
**石瓦台阶**是[石瓦](^supplementaries:stone_tiles)的[台阶](^minecraft:tag/slabs)变种。

;;;;;

&title(合成)
<recipe;supplementaries:stone_tile_slab>
<recipe;supplementaries:stonecutting/stone_tile_slab>
