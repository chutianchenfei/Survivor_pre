```json
{
  "title": "金属框架与金属支架",
  "icon": "suppsquared:metal_frame",
  "categories": [
    "minecraft:blocks",
    "minecraft:group/functional_blocks"
  ],
  "associated_items": [
    "suppsquared:metal_frame",
    "suppsquared:metal_brace",
    "suppsquared:metal_cross_brace"
  ]
}
```

&spotlight(suppsquared:metal_frame)
[木框架与木支架](^supplementaries:timber_frame)的金属变种，有3种形状：**支架**、**交叉支架**、**框架**。

;;;;;

&title(合成)
<recipe;suppsquared:metal_frame>
<recipe;suppsquared:metal_brace>

;;;;;

&title(合成)
<recipe;suppsquared:metal_cross_brace>
