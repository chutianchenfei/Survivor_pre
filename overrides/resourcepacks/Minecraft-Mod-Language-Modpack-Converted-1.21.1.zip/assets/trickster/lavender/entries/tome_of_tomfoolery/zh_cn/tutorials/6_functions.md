```json
{
  "title": "7. 法术片段",
  "icon": "minecraft:paper",
  "ordinal": 6,
  "category": "trickster:tutorials"
}
```

即将到来！
