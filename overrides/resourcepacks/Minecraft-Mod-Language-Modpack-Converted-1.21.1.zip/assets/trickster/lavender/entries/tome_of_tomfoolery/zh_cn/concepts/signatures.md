```json
{
  "title": "戏法签名",
  "icon": "minecraft:writable_book",
  "category": "trickster:concepts"
}
```

即将到来！碰到困难可以来Discord寻求帮助！
