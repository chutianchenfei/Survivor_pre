```json
{
  "title": "反应触发物品",
  "icon": "minecraft:diamond_sword",
  "category": "trickster:concepts"
}
```

尽管[魔杖](^trickster:items/wand)是快速施法最常用、最泛用的手段，它也并非是唯一的选择。其他物品会在达成特定要求时施放抄入的法术。物品的种类及其具体要求见后页。

;;;;;

<|page-title@lavender:book_components|title=战士之怒|>抄入工具和近战武器后，战士之怒会在其对实体造成伤害时执行法术。所攻击的实体传入为第一参数。

;;;;;

<|page-title@lavender:book_components|title=勘探工之喜|>在破坏方块之前，抄入手持工具的勘探工之喜即会开始执行法术。所破坏方块的位置传入为第一参数。

;;;;;

<|page-title@lavender:book_components|title=表演家之赦|>在摔落到方块上的前一瞬，表演家之赦即会触发足部装备中抄有的法术。穿戴者摔落过的距离传入为第一参数。倘若落到水中接受了缓冲，表演家便不会前来赦免痛苦。
