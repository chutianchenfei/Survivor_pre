```json
{
  "title": "开裂的回响晶结",
  "icon": "trickster:cracked_echo_knot",
  "category": "trickster:items",
  "required_advancements": [
    "trickster:cracked_echo_knot"
  ],
  "ordinal": 15
}
```

这些[晶结](^trickster:items/knots)出自古老文明的废墟，残破但仍能够使用。它们会以绿宝石晶结的两倍速度自然充能，其容量则是钻石晶结的两倍。

;;;;;

WIP：代号“Aldayim的矩阵”