```json
{
  "title": "粒子",
  "icon": "minecraft:firework_rocket",
  "category": "trickster:ploys",
  "additional_search_terms": [
    "繁盛之技巧"
  ]
}
```

能在世界中显示粒子的多种技巧术。

;;;;;

<|glyph@trickster:templates|trick-id=trickster:highlight,title=繁盛之技巧|>

vector... | vector[] -> vector

---

高亮给定的方块，返回第一个输入。