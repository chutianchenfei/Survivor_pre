```json
{
  "title": "戏法",
  "icon": "trickster:written_scroll",
  "ordinal": 1
}
```

戏法是法术的基本构成单元。


戏法会接收输入、输出、或二者均取，并对其执行一定的操作，或是产生些许副作用。