```json
{
  "title": "技巧术",
  "icon": "trickster:wand",
  "ordinal": 3,
  "parent": "trickster:tricks"
}
```

技巧术是一类戏法，能够执行特定操作，并对世界造成影响，或至少对一些事物造成影响。


通常来说，技巧术会消耗魔力。有消耗的图案下方画有一个涡旋。将鼠标悬停在其上以查看消耗量的计算方式。